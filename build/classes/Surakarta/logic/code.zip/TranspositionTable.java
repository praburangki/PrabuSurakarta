package Surakarta.logic;

import java.util.Hashtable;

/**
 *
 * @author praburangki
 */
public class TranspositionTable extends Hashtable<Board, Evaluate> {
    
}
